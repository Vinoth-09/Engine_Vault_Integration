# VaultService - HashiCorp Vault Integration Service

A Windows Service that provides secure integration with HashiCorp Vault using TLS client certificate authentication. The service includes features like secret caching, automatic refresh, and secure secret management.

## Features

- **Secure Authentication**: Uses TLS client certificate authentication with HashiCorp Vault
- **Thread-Safe Caching**: Implements a high-performance, thread-safe in-memory cache for secrets
- **Automatic Refresh**: Periodically refreshes secrets from Vault based on configurable intervals
- **Bulk Operations**: Supports retrieving and managing multiple secrets in a single operation
- **Robust Error Handling**: Comprehensive error handling and logging throughout the application
- **Easy Deployment**: Simple installation and configuration process
- **Monitoring**: Built-in health checks and monitoring capabilities

## Prerequisites

- Windows Server 2012 R2 or later / Windows 10 or later
- .NET Framework 4.8 or later
- HashiCorp Vault server (v1.0.0 or later recommended)
- TLS client certificate for Vault authentication
- Administrative privileges for service installation

## Installation

### 1. Build the Solution

```bash
dotnet restore
dotnet publish -c Release -r win-x64 --self-contained false
```

### 2. Configure the Service

Edit the `appsettings.json` file to configure your Vault connection and service settings:

```json
{
  "VaultSettings": {
    "VaultAddress": "https://vault.example.com:8200",
    "ClientCertificatePath": "C:\\Certificates\\vault-client.p12",
    "ClientCertificatePassword": "your-certificate-password",
    "VaultNamespace": "",
    "SecretPaths": [
      "secret/data/app/database",
      "secret/data/app/api-keys"
    ]
  },
  "ServiceSettings": {
    "ServiceName": "VaultService",
    "DisplayName": "Vault Service",
    "PollingIntervalSeconds": 60
  },
  "CacheSettings": {
    "Enabled": true,
    "ExpirationMinutes": 30,
    "CleanupIntervalMinutes": 5
  }
}
```

### 3. Install the Service

Run the following command in an elevated PowerShell window:

```powershell
# Install the service
.\install-service.ps1

# Or with custom settings
.\install-service.ps1 -ServiceName "MyVaultService" -Path "C:\Path\To\Service"
```

### 4. Verify Installation

Check that the service is running:

```powershell
Get-Service -Name VaultService
```

## Configuration

### Vault Settings

| Setting | Description | Default |
|---------|-------------|---------|
| VaultAddress | URL of the Vault server | Required |
| ClientCertificatePath | Path to the client certificate file | Required |
| ClientCertificatePassword | Password for the client certificate | Required |
| VaultNamespace | Vault namespace (if using Vault Enterprise) | Empty |
| SecretPaths | List of secret paths to monitor | Empty list |

### Service Settings

| Setting | Description | Default |
|---------|-------------|---------|
| ServiceName | Windows Service name | VaultService |
| DisplayName | Display name of the service | Vault Service |
| PollingIntervalSeconds | How often to refresh secrets from Vault (seconds) | 60 |
| StartupDelaySeconds | Delay before the first secret refresh (seconds) | 10 |

### Cache Settings

| Setting | Description | Default |
|---------|-------------|---------|
| Enabled | Whether caching is enabled | true |
| ExpirationMinutes | How long to cache secrets (minutes) | 30 |
| CleanupIntervalMinutes | How often to clean up expired cache items (minutes) | 5 |

## Usage

### Starting/Stopping the Service

```powershell
# Start the service
Start-Service -Name VaultService

# Stop the service
Stop-Service -Name VaultService -Force

# Restart the service
Restart-Service -Name VaultService -Force
```

### Viewing Logs

Logs are written to the following location by default:

```
%PROGRAMDATA%\VaultService\Logs\VaultService-.log
```

You can also view logs in the Windows Event Viewer under:

```
Windows Logs > Application
```

### Uninstalling the Service

```powershell
.\uninstall-service.ps1
```

## Security Considerations

1. **Certificate Security**:
   - Store the client certificate in a secure location with restricted access
   - Use strong passwords for certificate protection
   - Rotate certificates regularly

2. **Service Account**:
   - The service runs as LocalSystem by default
   - For production, consider using a dedicated service account with least privileges

3. **Secrets Management**:
   - Never store sensitive information in configuration files
   - Use environment variables or secure secret stores for production credentials

## Troubleshooting

### Common Issues

1. **Service Fails to Start**
   - Check the application logs in Event Viewer
   - Verify the Vault server is accessible from the service host
   - Ensure the certificate file exists and is accessible

2. **Authentication Failures**
   - Verify the client certificate is valid and not expired
   - Check that the certificate is properly configured in Vault
   - Ensure the certificate's subject matches the Vault role configuration

3. **Permission Issues**
   - The service account needs read access to the certificate file
   - The service account needs network access to the Vault server

### Logging

Logs are written to both the Windows Event Log and a file. The log level can be adjusted in the `appsettings.json` file:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft": "Warning"
    }
  }
}
```

## Development

### Building from Source

1. Clone the repository
2. Restore NuGet packages
3. Build the solution

```bash
git clone <repository-url>
cd VaultService
dotnet restore
dotnet build
```

### Running in Development Mode

You can run the service in console mode for debugging:

```bash
dotnet run --configuration Debug
```

### Testing

Run the unit tests:

```bash
dotnet test
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request
