using System;
using System.ComponentModel;
using System.Configuration;
using System.Configuration.Install;
using System.ServiceProcess;

namespace VaultWindowsService
{
    /// <summary>
    /// Installer for the Vault Windows Service
    /// Handles service installation, configuration, and removal
    /// </summary>
    [RunInstaller(true)]
    public partial class VaultServiceInstaller : Installer
    {
        private ServiceProcessInstaller serviceProcessInstaller;
        private ServiceInstaller serviceInstaller;

        public VaultServiceInstaller()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            // Create service process installer
            serviceProcessInstaller = new ServiceProcessInstaller();
            serviceProcessInstaller.Account = ServiceAccount.LocalSystem;
            serviceProcessInstaller.Username = null;
            serviceProcessInstaller.Password = null;

            // Create service installer
            serviceInstaller = new ServiceInstaller();
            
            // Get service configuration from App.config
            serviceInstaller.ServiceName = ConfigurationManager.AppSettings["ServiceName"] ?? "VaultWindowsService";
            serviceInstaller.DisplayName = ConfigurationManager.AppSettings["ServiceDisplayName"] ?? "Vault Configuration Service";
            serviceInstaller.Description = ConfigurationManager.AppSettings["ServiceDescription"] ?? 
                "Windows service that retrieves and caches application settings from HashiCorp Vault";
            
            serviceInstaller.StartType = ServiceStartMode.Automatic;
            serviceInstaller.DelayedAutoStart = true;

            // Add installers to the collection
            Installers.Add(serviceProcessInstaller);
            Installers.Add(serviceInstaller);
        }

        /// <summary>
        /// Called during service installation
        /// </summary>
        /// <param name="stateSaver">State saver</param>
        public override void Install(System.Collections.IDictionary stateSaver)
        {
            try
            {
                base.Install(stateSaver);
                
                // Log successful installation
                System.Diagnostics.EventLog.WriteEntry("Application", 
                    $"VaultWindowsService installed successfully as '{serviceInstaller.ServiceName}'", 
                    System.Diagnostics.EventLogEntryType.Information);
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", 
                    $"Failed to install VaultWindowsService: {ex.Message}", 
                    System.Diagnostics.EventLogEntryType.Error);
                throw;
            }
        }

        /// <summary>
        /// Called during service uninstallation
        /// </summary>
        /// <param name="savedState">Saved state</param>
        public override void Uninstall(System.Collections.IDictionary savedState)
        {
            try
            {
                base.Uninstall(savedState);
                
                // Log successful uninstallation
                System.Diagnostics.EventLog.WriteEntry("Application", 
                    $"VaultWindowsService uninstalled successfully", 
                    System.Diagnostics.EventLogEntryType.Information);
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", 
                    $"Failed to uninstall VaultWindowsService: {ex.Message}", 
                    System.Diagnostics.EventLogEntryType.Error);
                throw;
            }
        }

        /// <summary>
        /// Called before service installation
        /// </summary>
        /// <param name="stateSaver">State saver</param>
        protected override void OnBeforeInstall(System.Collections.IDictionary stateSaver)
        {
            try
            {
                // Ensure required directories exist
                var cacheFilePath = ConfigurationManager.AppSettings["CacheFilePath"];
                if (!string.IsNullOrEmpty(cacheFilePath))
                {
                    var cacheDirectory = System.IO.Path.GetDirectoryName(cacheFilePath);
                    if (!System.IO.Directory.Exists(cacheDirectory))
                    {
                        System.IO.Directory.CreateDirectory(cacheDirectory);
                    }
                }

                // Create logs directory
                var logsDirectory = @"C:\ProgramData\VaultWindowsService\Logs";
                if (!System.IO.Directory.Exists(logsDirectory))
                {
                    System.IO.Directory.CreateDirectory(logsDirectory);
                }

                base.OnBeforeInstall(stateSaver);
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", 
                    $"Error during VaultWindowsService pre-installation: {ex.Message}", 
                    System.Diagnostics.EventLogEntryType.Warning);
                base.OnBeforeInstall(stateSaver);
            }
        }

        /// <summary>
        /// Called before service uninstallation
        /// </summary>
        /// <param name="savedState">Saved state</param>
        protected override void OnBeforeUninstall(System.Collections.IDictionary savedState)
        {
            try
            {
                // Stop the service if it's running
                using (var serviceController = new ServiceController(serviceInstaller.ServiceName))
                {
                    if (serviceController.Status == ServiceControllerStatus.Running)
                    {
                        serviceController.Stop();
                        serviceController.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30));
                    }
                }

                base.OnBeforeUninstall(savedState);
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry("Application", 
                    $"Error during VaultWindowsService pre-uninstallation: {ex.Message}", 
                    System.Diagnostics.EventLogEntryType.Warning);
                base.OnBeforeUninstall(savedState);
            }
        }
    }
}
